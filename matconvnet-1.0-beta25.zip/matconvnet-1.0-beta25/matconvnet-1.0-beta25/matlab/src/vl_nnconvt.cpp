#if ENABLE_GPU
#error This file should not be compiled with GPU support enabled
#endif
#include "vl_nnconvt.cu"
